datetimepicker
==============
[Documentation][doc]


jQuery Plugin Date and Time Picker

DateTimePicker

![ScreenShot](/screen/1.png)

DatePicker

![ScreenShot](/screen/2.png)

TimePicker

![ScreenShot](/screen/3.png)

[doc]: http://xdsoft.net/jqplugins/datetimepicker/
